// app/(routes)/dashboard/budgets/page.tsx
// "use client";

import DashboardLayout from './layout';

export default function BudgetsPage() {
  return (
    <DashboardLayout>
      <h1>Budgets</h1>
    </DashboardLayout>
  );
}
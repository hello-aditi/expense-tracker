import React from "react";

export default function DashboardPage() {
  return (
    <div>
      <h1>I am your dashboard default</h1>
    </div>
  );
}